var bodyParser = require('body-parser');
const cors = require('cors');

var request = require("request"),
    http = require("http"),
   
config = require('./config'),
    PORT = config.port,
    Users = require('./users_new.js')

var mysql = require('mysql');
var pool = mysql.createPool({
    host: config.mysql_host,
    user: config.mysql_user,
    password: config.mysql_password,
    database: config.mysql_database

});
var express=require("express")
var app = express();
app.use(bodyParser.json());
app.use(cors({ origin: true, credentials: true }));







var httpsServer = http.createServer(app);

var server = httpsServer.listen(config.port, function () {
    var host = server.address().address;
    var port = server.address().port;

    console.log(' server listening on port', port);
});


app.post('/add_employee', function (req, res) {
    var userdata = req.body;
    Users.add_employee(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }
        if (config.DEBUG == 2)
            console.log();
        res.status(http_status_code).send(response);
    });
});
app.post('/employee_detail', function (req, res) {
    var userdata = req.body;
    Users.employee_detail(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }
        if (config.DEBUG == 2)
            console.log();
        res.status(http_status_code).send(response);
    });
});

app.post('/emp_delete', function (req, res) {
    var userdata = req.body;
    console.log(userdata);
    Users.emp_delete(userdata, pool, function (http_status_code, err, response) {
        if (err) {
            console.log(err);
            throw err;
        }
        if (config.DEBUG == 2)
            console.log();
        res.status(http_status_code).send(response);
    });
});
module.exports = app;