import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { NgxSmartModalService } from 'ngx-smart-modal';
import { ApiService } from './api.service';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ]
})
export class AppComponent {
  name = 'Angular 6';
  @ViewChild('myform') form: NgForm | undefined;
  data: any;
  editMode = false;
  editIndex: any;
  addForm: FormGroup | any;
bodyparser:any
  constructor(private fb: FormBuilder, public ngxSmartModalService: NgxSmartModalService, private apiservice: ApiService) {
    this.emp_list();
  }

  ngOnInit(): void {
    this.addForm = this.fb.group({
      name: [''],
      departments: [''],
      salary: [''],
      id: [''],
    });
  }

  emp_list() {
    const requestData = {
      id: '',
      keyword: this.bodyparser, 
      sortColumn: this.sortColumn,
      sortOrder: this.sortOrder
    };

    this.apiservice.post("employee_detail", requestData).subscribe((res: any) => {
      this.data = res.data;
    });
  }

  addData() {
    var val: any = this.addForm.value;
    console.log(val, 'this is data');
    this.apiservice.post("add_employee", val).subscribe((res: any) => {
      this.emp_list();
this.addForm.reset();
      this.ngxSmartModalService.close('myModal');
    });
  }

  onDel(id: any) {
    this.apiservice.post("emp_delete", { id: id }).subscribe((res: any) => {
            this.emp_list();

    });

  }

  onEdit(index: any) {
    
    this.editMode = true;
    this.editIndex = index;
    this.ngxSmartModalService.open('myModal');
    this.addForm.patchValue(index);
  }

  closeModal(id: any) {
    this.form?.resetForm();
    this.editMode = false;
    this.ngxSmartModalService.close(id);
  }
  onSearchKey(value:any){
    console.log("hello",value.value);
    this.bodyparser=value.value
    this.emp_list()

  }
  sortColumn: string = 'id'; 
  sortOrder: string = 'ASC';

onSort(column: string) {
    if (this.sortColumn === column) {
      this.sortOrder = this.sortOrder === 'ASC' ? 'DESC' : 'ASC';
    } else {
      this.sortColumn = column;
      this.sortOrder = 'ASC';
    }
    this.emp_list(); 
  }

  

  getSortClass(column: string, order: string) {

    return {
      'bi bi-caret-up-fill': this.sortColumn === column && this.sortOrder === 'ASC',
      'bi bi-caret-down-fill': this.sortColumn === column && this.sortOrder === 'DESC',
        'bi bi-caret-up': this.sortColumn !== column
    };
  }
}
